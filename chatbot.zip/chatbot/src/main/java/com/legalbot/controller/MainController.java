package com.legalbot.controller;

import com.legalbot.dao.MessageDAO;
import com.legalbot.model.Message;
import com.legalbot.service.OpenAIService;
import com.legalbot.service.DocumentService;
import com.legalbot.service.DatabaseService;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.VBox;
import javafx.stage.FileChooser;
import java.io.File;
import java.util.List;

public class MainController {

    @FXML
    private VBox chatContainer;

    @FXML
    private TextField inputField;

    @FXML
    private Label headerLabel;

    private OpenAIService openAIService;
    private DocumentService documentService;
    private MessageDAO messageDAO;

    private String currentApiKey = System.getenv("OPENAI_API_KEY");

    public void initialize() {
        openAIService = new OpenAIService(currentApiKey);
        documentService = new DocumentService();
        messageDAO = new MessageDAO();

        // Sequentially initialize DB and load history to avoid race conditions
        new Thread(() -> {
            DatabaseService.getInstance().initializeDatabase();

            // Re-load history after DB is ready (or determined to be offline)
            loadChatHistory();
        }).start();
    }

    private void loadChatHistory() {
        try {
            List<Message> history = messageDAO.getAll();
            Platform.runLater(() -> {
                chatContainer.getChildren().clear();
                for (Message msg : history) {
                    displayMessage(msg.getSender(), msg.getContent());
                }

                // Add welcome message only if history is empty
                if (history.isEmpty()) {
                    addBotMessage(
                            "Bonjour! Je suis votre assistant juridique. Comment puis-je vous aider aujourd'hui ?");
                }
            });
        } catch (Exception e) {
            System.err.println("Failed to load history: " + e.getMessage());
            // Fallback for offline mode
            Platform.runLater(() -> {
                if (chatContainer.getChildren().isEmpty()) {
                    addBotMessage(
                            "Bonjour! Je suis votre assistant juridique (Mode Hors-ligne). Comment puis-je vous aider ?");
                }
            });
        }
    }

    @FXML
    private void handleSendMessage() {
        String msgContent = inputField.getText().trim();
        if (msgContent.isEmpty())
            return;

        inputField.clear();
        addUserMessage(msgContent);

        new Thread(() -> {
            String response = openAIService.sendQuery(msgContent);
            Platform.runLater(() -> addBotMessage(response));
        }).start();
    }

    @FXML
    private void handleChatNav() {
        headerLabel.setText("Chat Juridique");
    }

    @FXML
    private void handleUploadNav() {
        headerLabel.setText("Analyse de Document");

        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Sélectionner un document juridique (PDF ou TXT)");
        fileChooser.getExtensionFilters().addAll(
                new FileChooser.ExtensionFilter("Documents", "*.pdf", "*.txt"));

        File selectedFile = fileChooser.showOpenDialog(headerLabel.getScene().getWindow());

        if (selectedFile != null) {
            addUserMessage("Analyse du document : " + selectedFile.getName());
            addBotMessage("Lecture du document en cours...");

            new Thread(() -> {
                try {
                    String content = documentService.readDocument(selectedFile);
                    String prompt = "Analyse ce document juridique et extrais les clauses importantes avec un résumé simple :\n\n"
                            + content;
                    String analysis = openAIService.sendQuery(prompt);

                    Platform.runLater(() -> addBotMessage(analysis));
                } catch (Exception e) {
                    Platform.runLater(() -> addBotMessage("⚠️ Erreur lors de l'analyse : " + e.getMessage()));
                }
            }).start();
        }
    }

    @FXML
    private void handleSettingsNav() {
        headerLabel.setText("Paramètres");
        addBotMessage("Configuration: \n- Base de données: " +
                (DatabaseService.getInstance().isDbAvailable() ? "Connecté (SQL Server)" : "Hors-ligne/Non configurée")
                +
                "\n- API Key: " + (currentApiKey != null ? "****" : "Non définie"));
    }

    private void addUserMessage(String text) {
        displayMessage("user", text);
        if (DatabaseService.getInstance().isDbAvailable()) {
            new Thread(() -> messageDAO.save(new Message("user", text))).start();
        }
    }

    private void addBotMessage(String text) {
        displayMessage("bot", text);
        if (DatabaseService.getInstance().isDbAvailable()) {
            new Thread(() -> messageDAO.save(new Message("bot", text))).start();
        }
    }

    private void displayMessage(String sender, String text) {
        Label msgLabel = new Label(text);
        msgLabel.setWrapText(true);
        if ("user".equals(sender)) {
            msgLabel.getStyleClass().add("user-message");
        } else {
            msgLabel.getStyleClass().add("bot-message");
        }

        Platform.runLater(() -> chatContainer.getChildren().add(msgLabel));
    }
}
