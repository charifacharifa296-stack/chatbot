package com.legalbot.controller;

import com.legalbot.dao.UserDAO;
import com.legalbot.model.User;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;

public class LoginController {

    @FXML
    private TextField usernameField;

    @FXML
    private PasswordField passwordField;

    @FXML
    private Label errorLabel;

    private UserDAO userDAO = new UserDAO();

    @FXML
    private void handleLogin() {
        String username = usernameField.getText();
        String password = passwordField.getText();

        if (username.isEmpty() || password.isEmpty()) {
            errorLabel.setText("Veuillez remplir tous les champs.");
            return;
        }

        // For demo purposes, we also allow admin/admin123 without DB
        if ((username.equals("admin") && password.equals("admin123"))) {
            proceedToMain();
            return;
        }

        User user = userDAO.authenticate(username, password);
        if (user != null) {
            proceedToMain();
        } else {
            errorLabel.setText("Identifiants incorrects.");
        }
    }

    private void proceedToMain() {
        try {
            Stage stage = (Stage) usernameField.getScene().getWindow();
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/com/legalbot/view/main_layout.fxml"));
            Parent root = fxmlLoader.load();

            Scene scene = new Scene(root, 1000, 700);
            String css = getClass().getResource("/styles/styles.css").toExternalForm();
            scene.getStylesheets().add(css);

            stage.setScene(scene);
            stage.centerOnScreen();
        } catch (IOException e) {
            e.printStackTrace();
            errorLabel.setText("Erreur lors du chargement de l'application.");
        }
    }
}
