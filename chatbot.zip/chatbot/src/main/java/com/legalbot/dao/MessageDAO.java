package com.legalbot.dao;

import com.legalbot.model.Message;
import com.legalbot.service.DatabaseService;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class MessageDAO {

    public void save(Message message) {
        String sql = "INSERT INTO Messages (sender, content, timestamp) VALUES (?, ?, ?)";
        try (Connection conn = DatabaseService.getInstance().getConnection();
                PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, message.getSender());
            pstmt.setString(2, message.getContent());
            pstmt.setTimestamp(3, Timestamp.valueOf(message.getTimestamp()));
            pstmt.executeUpdate();

        } catch (SQLException e) {
            System.err.println("Error saving message: " + e.getMessage());
            // Fallback: in a real app, we might log this or show an alert
        }
    }

    public List<Message> getAll() {
        List<Message> messages = new ArrayList<>();
        String sql = "SELECT * FROM Messages ORDER BY timestamp ASC";
        try (Connection conn = DatabaseService.getInstance().getConnection();
                Statement stmt = conn.createStatement();
                ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                Message msg = new Message();
                msg.setId(rs.getInt("id"));
                msg.setSender(rs.getString("sender"));
                msg.setContent(rs.getString("content"));
                msg.setTimestamp(rs.getTimestamp("timestamp").toLocalDateTime());
                messages.add(msg);
            }

        } catch (SQLException e) {
            System.err.println("Error getting messages: " + e.getMessage());
        }
        return messages;
    }
}
