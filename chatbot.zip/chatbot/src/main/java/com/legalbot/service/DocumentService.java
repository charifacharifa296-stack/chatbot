package com.legalbot.service;

import org.apache.pdfbox.Loader;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.text.PDFTextStripper;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;

public class DocumentService {

    public String readDocument(File file) throws IOException {
        String fileName = file.getName().toLowerCase();

        if (fileName.endsWith(".pdf")) {
            return readPdf(file);
        } else if (fileName.endsWith(".txt")) {
            return readText(file);
        } else {
            throw new IOException("Format de fichier non supporté. Veuillez utiliser PDF ou TXT.");
        }
    }

    private String readPdf(File file) throws IOException {
        try (PDDocument document = Loader.loadPDF(file)) {
            PDFTextStripper stripper = new PDFTextStripper();
            return stripper.getText(document);
        }
    }

    private String readText(File file) throws IOException {
        return Files.readString(file.toPath());
    }
}
