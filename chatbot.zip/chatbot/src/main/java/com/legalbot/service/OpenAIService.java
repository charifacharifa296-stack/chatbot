package com.legalbot.service;

import com.google.gson.Gson;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class OpenAIService {
    private final String apiKey;
    private final HttpClient client;
    private final Gson gson;

    // Fallback key handling should be better in prod, but for this demo:
    private static final String DEFAULT_MODEL = "gpt-3.5-turbo";

    public OpenAIService(String apiKey) {
        this.apiKey = apiKey;
        this.client = HttpClient.newHttpClient();
        this.gson = new Gson();
    }

    public String sendQuery(String prompt) {
        if (apiKey == null || apiKey.isEmpty()) {
            return "Erreur: Clé API OpenAI manquante. Veuillez configurer la clé dans les paramètres.";
        }

        try {
            Map<String, Object> body = new HashMap<>();
            body.put("model", DEFAULT_MODEL);

            List<Map<String, String>> messages = new ArrayList<>();
            Map<String, String> systemMsg = new HashMap<>();
            systemMsg.put("role", "system");
            systemMsg.put("content",
                    "Vous êtes un assistant juridique expert en droit marocain. Analysez les questions et répondez avec précision en citant si possible les articles de loi pertinents. Si vous ne savez pas, dites-le.");

            Map<String, String> userMsg = new HashMap<>();
            userMsg.put("role", "user");
            userMsg.put("content", prompt);

            messages.add(systemMsg);
            messages.add(userMsg);

            body.put("messages", messages);

            String jsonBody = gson.toJson(body);

            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create("https://api.openai.com/v1/chat/completions"))
                    .header("Content-Type", "application/json")
                    .header("Authorization", "Bearer " + apiKey)
                    .POST(HttpRequest.BodyPublishers.ofString(jsonBody, StandardCharsets.UTF_8))
                    .build();

            HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());

            if (response.statusCode() == 200) {
                // Parse response
                @SuppressWarnings("unchecked")
                Map<String, Object> responseMap = gson.fromJson(response.body(), Map.class);
                @SuppressWarnings("unchecked")
                List<Map<String, Object>> choices = (List<Map<String, Object>>) responseMap.get("choices");
                Map<String, Object> firstChoice = choices.get(0);
                @SuppressWarnings("unchecked")
                Map<String, Object> message = (Map<String, Object>) firstChoice.get("message");
                return (String) message.get("content");
            } else {
                return parseErrorResponse(response.statusCode(), response.body(), prompt);
            }

        } catch (Exception e) {
            e.printStackTrace();
            return "Erreur technique: " + e.getMessage();
        }
    }

    private String parseErrorResponse(int statusCode, String responseBody, String prompt) {
        try {
            // Try to parse the error JSON
            @SuppressWarnings("unchecked")
            Map<String, Object> errorMap = gson.fromJson(responseBody, Map.class);
            @SuppressWarnings("unchecked")
            Map<String, Object> error = (Map<String, Object>) errorMap.get("error");

            if (error != null) {
                String errorType = (String) error.get("type");
                String errorMessage = (String) error.get("message");

                // Handle specific error types with user-friendly messages
                switch (statusCode) {
                    case 401:
                        return "❌ Erreur d'authentification: Votre clé API OpenAI est invalide ou expirée. Veuillez vérifier vos paramètres.";

                    case 429:
                        if (errorType != null && errorType.equals("insufficient_quota")) {
                            return getMockResponse(prompt);
                        } else {
                            return "❌ Limite de taux dépassée: Trop de requêtes. Veuillez patienter quelques instants avant de réessayer.";
                        }

                    case 500:
                    case 502:
                    case 503:
                        return "❌ Erreur serveur OpenAI: Le service est temporairement indisponible. Veuillez réessayer plus tard.";

                    case 400:
                        return "❌ Requête invalide: "
                                + (errorMessage != null ? errorMessage : "Vérifiez votre requête et réessayez.");

                    default:
                        return "❌ Erreur API (" + statusCode + "): "
                                + (errorMessage != null ? errorMessage : responseBody);
                }
            }
        } catch (Exception e) {
            // If parsing fails, return a generic error message
        }

        // Fallback to generic error message
        return "❌ Erreur API (" + statusCode + "): Une erreur s'est produite lors de la communication avec OpenAI.";
    }

    private String getMockResponse(String prompt) {
        String p = prompt.toLowerCase();
        if (p.contains("sarl")) {
            return "[MODE DÉMO] La SARL au Maroc est régie par la loi 5-96. Principaux points :\n- Capital social librement fixé.\n- Entre 1 et 50 associés.\n- Immatriculation obligatoire au registre du commerce.";
        } else if (p.contains("bail") || p.contains("loyer")) {
            return "[MODE DÉMO] Le bail au Maroc est régi par la loi 67-12. Le contrat doit être écrit, le préavis de départ est généralement de 2 mois, et les augmentations sont plafonnées (8% max tous les 3 ans).";
        } else if (p.contains("490")) {
            return "[MODE DÉMO] L'article 490 du Code Pénal marocain concerne les relations hors mariage. Il prévoit une peine de 1 mois à 1 an d'emprisonnement.";
        } else if (p.contains("licenciement") || p.contains("travail")) {
            return "[MODE DÉMO] Le Code du Travail (Loi 65-99) définit le licenciement. Si abusif, le salarié a droit à des indemnités de préavis, de licenciement et de dommages-intérêts.";
        } else if (p.contains("bonjour") || p.contains("salut")) {
            return "[MODE DÉMO] Bonjour ! Je suis en mode démonstration car votre quota OpenAI est épuisé. Je peux quand même répondre à des questions de base sur la SARL, le bail, ou le code du travail.";
        }

        return "⚠️ [MODE DÉMO ACTIVÉ]\nVotre quota OpenAI est épuisé (Erreur 429). \n\nVoici ce que je peux dire sur votre demande : '"
                + prompt
                + "'. \n(Pour obtenir une réponse réelle par IA, veuillez créditer votre compte sur platform.openai.com)";
    }
}
