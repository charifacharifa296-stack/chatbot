package com.legalbot.service;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class DatabaseService {

    private static DatabaseService instance;
    private String jdbcUrl = "jdbc:sqlite:legalbot.db";
    private boolean dbAvailable = false;

    private DatabaseService() {
    }

    public static synchronized DatabaseService getInstance() {
        if (instance == null) {
            instance = new DatabaseService();
        }
        return instance;
    }

    public void initializeDatabase() {
        try (Connection conn = getConnection();
                Statement stmt = conn.createStatement()) {

            // Create Users table
            stmt.execute("CREATE TABLE IF NOT EXISTS Users (" +
                    "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    "username TEXT UNIQUE, " +
                    "password TEXT, " +
                    "fullName TEXT)");

            // Create Messages table
            stmt.execute("CREATE TABLE IF NOT EXISTS Messages (" +
                    "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    "sender TEXT, " +
                    "content TEXT, " +
                    "timestamp DATETIME DEFAULT CURRENT_TIMESTAMP)");

            // Add a default user if none exists
            stmt.execute(
                    "INSERT OR IGNORE INTO Users (username, password, fullName) VALUES ('admin', 'admin123', 'Administrateur')");

            System.out.println("Database (SQLite) initialized successfully.");
            dbAvailable = true;
        } catch (SQLException e) {
            System.err.println("Database initialization failed: " + e.getMessage());
            dbAvailable = false;
        }
    }

    public boolean isDbAvailable() {
        return dbAvailable;
    }

    @SuppressWarnings("exports")
    public Connection getConnection() throws SQLException {
        return DriverManager.getConnection(jdbcUrl);
    }

    public boolean testConnection() {
        try {
            Class.forName("org.sqlite.JDBC");
            try (Connection conn = getConnection()) {
                dbAvailable = true;
                return true;
            }
        } catch (Exception e) {
            dbAvailable = false;
            return false;
        }
    }
}
