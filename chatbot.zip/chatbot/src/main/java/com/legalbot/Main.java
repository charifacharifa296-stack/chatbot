package com.legalbot;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

import java.io.IOException;

@SuppressWarnings("unused")
public class Main extends Application {

    private static Scene scene;

    @Override
    public void start(Stage stage) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("/com/legalbot/view/login.fxml"));
        Parent root = fxmlLoader.load();

        scene = new Scene(root, 500, 600);
        scene.setFill(Color.TRANSPARENT);

        // Load CSS
        String css = Main.class.getResource("/styles/styles.css").toExternalForm();
        scene.getStylesheets().add(css);

        stage.setTitle("LegalBot - Connexion");
        stage.setScene(scene);
        stage.show();
    }

    public static void main(String[] args) {
        launch();
    }
}
