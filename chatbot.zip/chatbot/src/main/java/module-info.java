module com.legalbot {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;
    requires com.google.gson;
    requires java.net.http;
    requires org.apache.pdfbox;

    opens com.legalbot to javafx.fxml;
    opens com.legalbot.controller to javafx.fxml;
    opens com.legalbot.model to com.google.gson, javafx.base;

    exports com.legalbot;
    exports com.legalbot.service;
    exports com.legalbot.model;
    exports com.legalbot.dao;
    exports com.legalbot.controller;
}
