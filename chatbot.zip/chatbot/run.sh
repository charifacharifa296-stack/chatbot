#!/bin/bash
export OPENAI_API_KEY="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"


# Ensure Maven is set up
if [ ! -f "tools/apache-maven-3.9.6/bin/mvn" ]; then
    echo "Maven not found, running setup..."
    sh install_maven.sh
fi

MVN="tools/apache-maven-3.9.6/bin/mvn"

echo "Compiling and Running LegalBot..."
# Using javafx:run goal
"$MVN" clean javafx:run
