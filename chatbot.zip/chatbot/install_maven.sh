#!/bin/bash
echo "Checking for Maven..."
if command -v mvn &> /dev/null; then
    echo "Maven is already installed."
    exit 0
fi

if [ -d "tools/apache-maven-3.9.6" ]; then
    echo "Maven is already downloaded in tools/."
    exit 0
fi

echo "Downloading Maven 3.9.6..."
mkdir -p tools
curl -o tools/maven.tar.gz https://archive.apache.org/dist/maven/maven-3/3.9.6/binaries/apache-maven-3.9.6-bin.tar.gz

echo "Extracting Maven..."
tar -xzf tools/maven.tar.gz -C tools/
rm tools/maven.tar.gz

echo "Maven installed in tools/apache-maven-3.9.6"
